package vehicle;

import java.util.Random;

public class Car {

    //Step 5 write the shell code to match the UML Car diagram
    private static int vehicleCounter = 2000 ;
    private static String CAR_FACTORY_ID = "NORWOOD";
    private static String carID;
    private static String color;
    private static String factory;
    private static int numberofDoors;
    private static double price;
    private static int mileage;
    public static String doYouLikeit;

    //constructors
    public Car () {

        Random rndGen = new Random();
        String CarID = "VIN" + CAR_FACTORY_ID + "-" + vehicleCounter;
        double vehicleCounter = + +;
        String factory = CAR_FACTORY_ID;
        int numberofdoors = 2;
        color = "Red";
        mileage = 0;
        //?price = rndGen.NextInt (max - min) + min;
        price = rndGen.nextInt(45000 - 35000) + 35000;
        String doYouLikeIt = "Yes";
    }

    Car(String color, int numberofDoors) {

    }

    Car(String color, int numberOfDoors, double price, int mileage) {

    }

    int getVehicleCounter(){
        return 0;
    }

    public static void setVehicleCounter(int vehicleCounter) {

    }
    public static String getCarID;
    public static String getColor;
    public static void setColor(String color){

    }
    public String getFactory;
    public int getNumberofDoors;


    public static void setNumberofDoors(int numberofDoors){

    }

    public double getPrice;
    public static void classDisplayInfo(){

    }
    public static void displayInfo(){

    }
}
